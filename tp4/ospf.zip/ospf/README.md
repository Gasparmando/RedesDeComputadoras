# OSPF with IPv6
To create routers with OSPFv3 and IPv6 configuration it is necessary to execute docker-compose:

```
$ sudo docker-compose up
```

